from PIL import Image, ImageDraw
import pygetwindow as gw
import time
import os
import ctypes
from ctypes import windll

# Definir a estrutura RECT
class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long),
                ("top", ctypes.c_long),
                ("right", ctypes.c_long),
                ("bottom", ctypes.c_long)]

class ComparadorDeImagem:

    def __init__(self):
        self.analyze()

    def get_window_rect(self, hwnd):
        rect = RECT()
        windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        return rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top

    def minimize_window(self, hwnd):
        windll.user32.ShowWindow(hwnd, 6)  # 6 é o código para minimizar

    def analyze(self):
        # Criar diretórios se não existirem
        if not os.path.exists("Screenshots"):
            os.makedirs("Screenshots")
        if not os.path.exists("Results"):
            os.makedirs("Results")

        # Espera alguns segundos antes de começar para que você possa minimizar manualmente janelas indesejadas
        time.sleep(5)

        # Obtém todas as janelas abertas
        janelas = gw.getAllTitles()

        for nome_programa in janelas:
            # Ignora as janelas sem título
            if not nome_programa:
                continue

            try:
                janela_programa = gw.getWindowsWithTitle(nome_programa)[0]
            except IndexError:
                continue

            # Ignora a barra de tarefas e outros elementos indesejados
            if janela_programa.isMinimized:
                continue

            # Obtém o identificador da janela
            hwnd = windll.user32.FindWindowW(None, nome_programa)

            # Minimiza a janela
            self.minimize_window(hwnd)

            # Obtém as dimensões da janela sem ativá-la
            left, top, width, height = self.get_window_rect(hwnd)

            # Tira um screenshot da janela do programa sem ativá-la
            screenshot_path = f"Screenshots/{nome_programa.replace(' ', '_')}.PNG"
            ImageGrab.grab(bbox=(left, top, left + width, top + height)).save(screenshot_path)

            # Restaura a janela para o estado anterior
            windll.user32.ShowWindow(hwnd, 9)  # 9 é o código para restaurar

            # Carrega a imagem capturada
            imagem1 = Image.open(screenshot_path)
            imagem2 = Image.open("celogo2.png")  # Colocar aqui o diretório da segunda imagem a ser comparada

            colunas = 20
            linhas = 20
            tela_altura, tela_largura = imagem1.size

            bloco_largura = ((tela_altura - 1) // colunas) + 1
            bloco_altura = ((tela_largura - 1) // linhas) + 1

            for y in range(0, tela_largura, bloco_altura + 1):
                for x in range(0, tela_altura, bloco_largura + 1):
                    regiao_imagem1 = self.processar_regiao(imagem1, x, y, bloco_largura, bloco_altura)
                    regiao_imagem2 = self.processar_regiao(imagem2, x, y, bloco_largura, bloco_altura)

                    # Compara as duas regiões das imagem, e se forem diferentes, ele desenha um retângulo na região
                    if regiao_imagem1 is not None and regiao_imagem2 is not None and regiao_imagem2 != regiao_imagem1:
                        draw = ImageDraw.Draw(imagem1)
                        draw.rectangle((x, y, x + bloco_largura, y + bloco_altura), outline="red")

            imagem1.save(f"Results/{nome_programa.replace(' ', '_')}_result.png")

    def processar_regiao(self, imagem, x, y, largura, altura):
        regiao_total = 0

        # Fator de sensitividade.
        # quanto maior o fator, menor a sensibilidade
        fator = 100

        for cordenadaY in range(y, y + altura):
            for cordenadaX in range(x, x + largura):
                try:
                    pixel = imagem.getpixel((cordenadaX, cordenadaY))
                    regiao_total += sum(pixel) / 4
                except:
                    return

        return regiao_total / fator

ComparadorDeImagem()
